import json
import boto3
import pandas as pd
from datetime import datetime
from io import StringIO

def products(prddata):
    products_list = []
    country = prddata['data']['country']
    for prd in prddata['data']['products']:
        asin = prd['asin']
        product_title = prd['product_title']
        product_price = prd['product_price']
        product_original_price = prd['product_original_price']
        currency = prd['currency']
        product_star_rating = prd['product_star_rating']
        product_num_ratings = prd['product_num_ratings']
        product_url = prd['product_url']
        product_photo = prd['product_photo']
        product_num_offers = prd['product_num_offers']
        product_minimum_offer_price = prd['product_minimum_offer_price']
        is_best_seller = prd['is_best_seller']
        is_amazon_choice = prd['is_amazon_choice']
        is_prime = prd['is_prime']
        climate_pledge_friendly = prd['climate_pledge_friendly']
        sales_volume = prd['sales_volume']
        delivery = prd['delivery']
        has_variations = prd['has_variations']

        prd_data = {'asin':asin,'country':country,'product_title':product_title,'product_price':product_price,'product_original_price':product_original_price,'currency':currency,'product_star_rating':product_star_rating,'product_num_ratings':product_num_ratings,'product_url':product_url,'product_photo':product_photo,'product_num_offers':product_num_offers,'product_minimum_offer_price':product_minimum_offer_price,'is_best_seller':is_best_seller,'is_amazon_choice':is_amazon_choice,'is_prime':is_prime,'climate_pledge_friendly':climate_pledge_friendly,'sales_volume':sales_volume,'delivery':delivery,'has_variations':has_variations}

        products_list.append(prd_data)
    return products_list

def phones(phdata):
    phones_list = []
    country = phdata['data']['country']
    for ph in phdata['data']['products']:
        asin = ph['asin']
        product_title = ph['product_title']
        product_price = ph['product_price']
        product_original_price = ph['product_original_price']
        currency = ph['currency']
        product_star_rating = ph['product_star_rating']
        product_num_ratings = ph['product_num_ratings']
        product_url = ph['product_url']
        product_photo = ph['product_photo']
        product_num_offers = ph['product_num_offers']
        product_minimum_offer_price = ph['product_minimum_offer_price']
        is_best_seller = ph['is_best_seller']
        is_amazon_choice = ph['is_amazon_choice']
        is_prime = ph['is_prime']
        climate_pledge_friendly = ph['climate_pledge_friendly']
        sales_volume = ph['sales_volume']
        delivery = ph['delivery']
        has_variations = ph['has_variations']

        ph_data = {'asin':asin,'country':country,'product_title':product_title,'product_price':product_price,'product_original_price':product_original_price,'currency':currency,'product_star_rating':product_star_rating,'product_num_ratings':product_num_ratings,'product_url':product_url,'product_photo':product_photo,'product_num_offers':product_num_offers,'product_minimum_offer_price':product_minimum_offer_price,'is_best_seller':is_best_seller,'is_amazon_choice':is_amazon_choice,'is_prime':is_prime,'climate_pledge_friendly':climate_pledge_friendly,'sales_volume':sales_volume,'delivery':delivery,'has_variations':has_variations}

        phones_list.append(ph_data)
    return phones_list

def deals(dealsdata):
    deals_list = []
    country = dealsdata['parameters']['country']
    for deals in dealsdata['data']['deals']:
        deal_id = deals['deal_id']
        deal_type = deals['deal_type']
        deal_title = deals['deal_title']
        deal_photo = deals['deal_photo']
        deal_state = deals['deal_state']
        deal_url = deals['deal_url']
        canonical_deal_url = deals['canonical_deal_url']
        deal_starts_at = deals['deal_starts_at']
        deal_ends_at = deals['deal_ends_at']
        deal_price = deals['deal_price']['amount']
        list_price = deals['list_price']['amount']
        savings_percentage = deals['savings_percentage']
        savings_amount = deals['savings_amount']['amount']
        deal_badge = deals['deal_badge']
        type = deals['type']
        product_asin = deals['product_asin']

        deals_data = {'deal_id':deal_id,'country':country,'deal_type':deal_type,'deal_title':deal_title,'deal_photo':deal_photo,'deal_state':deal_state,'deal_url':deal_url,'canonical_deal_url':canonical_deal_url,'deal_starts_at':deal_starts_at,'deal_ends_at':deal_ends_at,'deal_price':deal_price,'list_price':list_price,'savings_percentage':savings_percentage,'savings_amount':savings_amount,'deal_badge':deal_badge,'type':type,'product_asin':product_asin}

        deals_list.append(deals_data)
    return deals_list

def bestseller(bestsellerdata):
    bestseller_list = []
    country = bestsellerdata['parameters']['country']
    for bestseller in bestsellerdata['data']['best_sellers']:
        asin = bestseller['asin']
        product_title = bestseller['product_title']
        product_price = bestseller['product_price']
        product_star_rating = bestseller['product_star_rating']
        product_num_ratings = bestseller['product_num_ratings']
        product_url = bestseller['product_url']
        product_photo = bestseller['product_photo']
        rank_change_label = bestseller['rank_change_label']

        bestseller_data = {'asin':asin,'country':country,'product_title':product_title,'product_price':product_price,'product_star_rating':product_star_rating,'product_num_ratings':product_num_ratings,'product_url':product_url,'product_photo':product_photo,'rank_change_label':rank_change_label}

        bestseller_list.append(bestseller_data)
    return bestseller_list

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    Bucket = "amazon-products-extracts-chiranjeevi"
    products_Key = "raw_data/to_processed/products/"
    deals_Key = "raw_data/to_processed/deals/"
    bestseller_Key = "raw_data/to_processed/bestsellers/"
    phones_Key = "raw_data/to_processed/phones/"
    
    #print(s3.list_objects(Bucket=Bucket, Prefix=Key)['Contents'][1:])

    bestseller_data = []
    deals_data = []
    phones_data = []
    products_data = []
    amazon_keys = []

    for file in s3.list_objects(Bucket=Bucket, Prefix=products_Key)['Contents'][1:]:
        file_key = file['Key']
        if file_key.split('.')[-1] == "json":
            response = s3.get_object(Bucket=Bucket, Key=file_key)
            content = response['Body']
            jsonObject = json.loads(content.read())
            products_data.append(jsonObject)
            amazon_keys.append(file_key)

    for prddata in products_data:
        products_list = products(prddata)

        products_df = pd.DataFrame.from_dict(products_list)

        products_key = "transformed_data/products_data/products_transformed_" + str(datetime.now()) + ".csv"
        products_buffer=StringIO()
        products_df.to_csv(products_buffer, index=False)
        products_content = products_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=products_key, Body=products_content)

    for file in s3.list_objects(Bucket=Bucket, Prefix=phones_Key)['Contents'][1:]:
        file_key = file['Key']
        if file_key.split('.')[-1] == "json":
            response = s3.get_object(Bucket=Bucket, Key=file_key)
            content = response['Body']
            jsonObject = json.loads(content.read())
            phones_data.append(jsonObject)
            amazon_keys.append(file_key)

    for phdata in phones_data:
        phones_list = phones(phdata)

        phones_df = pd.DataFrame.from_dict(phones_list)

        phones_key = "transformed_data/phones_data/phones_transformed_" + str(datetime.now()) + ".csv"
        phones_buffer=StringIO()
        phones_df.to_csv(phones_buffer, index=False)
        phones_content = phones_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=phones_key, Body=phones_content)

    for file in s3.list_objects(Bucket=Bucket, Prefix=deals_Key)['Contents'][1:]:
        file_key = file['Key']
        if file_key.split('.')[-1] == "json":
            response = s3.get_object(Bucket=Bucket, Key=file_key)
            content = response['Body']
            jsonObject = json.loads(content.read())
            deals_data.append(jsonObject)
            amazon_keys.append(file_key)

    for dealsdata in deals_data:
        deals_list = deals(dealsdata)

        deals_df = pd.DataFrame.from_dict(deals_list)

        deals_key = "transformed_data/deals_data/deals_transformed_" + str(datetime.now()) + ".csv"
        deals_buffer=StringIO()
        deals_df.to_csv(deals_buffer, index=False)
        deals_content = deals_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=deals_key, Body=deals_content)

    for file in s3.list_objects(Bucket=Bucket, Prefix=bestseller_Key)['Contents'][1:]:
        file_key = file['Key']
        if file_key.split('.')[-1] == "json":
            response = s3.get_object(Bucket=Bucket, Key=file_key)
            content = response['Body']
            jsonObject = json.loads(content.read())
            bestseller_data.append(jsonObject)
            amazon_keys.append(file_key)

    for bestsellerdata in bestseller_data:
        bestseller_list = bestseller(bestsellerdata)

        bestseller_df = pd.DataFrame.from_dict(bestseller_list)

        bestseller_key = "transformed_data/bestseller_data/bestseller_transformed_" + str(datetime.now()) + ".csv"
        bestseller_buffer=StringIO()
        bestseller_df.to_csv(bestseller_buffer, index=False)
        bestseller_content = bestseller_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=bestseller_key, Body=bestseller_content)

    #print(amazon_keys)
    for key in amazon_keys:
        copy_source = {
        'Bucket': Bucket,
        'Key': key
        }
        s3_resource.meta.client.copy(copy_source, Bucket, 'raw_data/processed/' + key.split("/")[-1])    
        s3_resource.Object(Bucket, key).delete()
