import json
import os
import boto3
from datetime import datetime
import requests

def lambda_handler(event, context):
    url_search = "https://real-time-amazon-data.p.rapidapi.com/search"
    url_productsbycategory = "https://real-time-amazon-data.p.rapidapi.com/products-by-category"
    url_bestseller = "https://real-time-amazon-data.p.rapidapi.com/best-sellers"    
    url_deals = "https://real-time-amazon-data.p.rapidapi.com/deals-v2"

    search_querystring = {"query":"Phone","page":"1","country":"US","sort_by":"RELEVANCE","product_condition":"ALL","is_prime":"false","deals_and_discounts":"NONE"}
    productsbycategory_querystring = {"category_id":"2478868012","page":"1","country":"US","sort_by":"RELEVANCE","product_condition":"ALL","is_prime":"false","deals_and_discounts":"NONE"}
    bestseller_querystring = {"category":"software","type":"BEST_SELLERS","page":"1","country":"US"}
    deals_querystring = {"country":"US","min_product_star_rating":"ALL","price_range":"ALL","discount_range":"ALL"}

    rapidapi_key = os.environ.get('rapidapi_key')
    rapidapi_host = os.environ.get('rapidapi_host')

    headers = {
        "x-rapidapi-key": rapidapi_key,
        "x-rapidapi-host": rapidapi_host
    }

    search_response = requests.get(url_search, headers=headers, params=search_querystring)
    productsbycategory_response = requests.get(url_productsbycategory, headers=headers, params=productsbycategory_querystring)
    bestseller_response = requests.get(url_bestseller, headers=headers, params=bestseller_querystring)
    deals_response = requests.get(url_deals, headers=headers, params=deals_querystring)

    amazon_searchdata = search_response.json()
    amazon_productsbycategory = productsbycategory_response.json()
    amazon_bestseller = bestseller_response.json()
    amazon_deals = deals_response.json()

    amazon_phones_file = "amazon_phones_raw_" + str(datetime.now()) + ".json"
    amazon_products_file = "amazon_products_raw_" + str(datetime.now()) + ".json"
    amazon_bestseller_file = "amazon_bestseller_raw_" + str(datetime.now()) + ".json"
    amazon_deals_file = "amazon_deals_raw_" + str(datetime.now()) + ".json"

    client = boto3.client('s3')
    client.put_object(Bucket='amazon-products-extracts-chiranjeevi', Key="raw_data/to_processed/phones/" + amazon_phones_file, Body=json.dumps(amazon_searchdata))  
    client.put_object(Bucket='amazon-products-extracts-chiranjeevi', Key="raw_data/to_processed/products/" + amazon_products_file, Body=json.dumps(amazon_productsbycategory))  
    client.put_object(Bucket='amazon-products-extracts-chiranjeevi', Key="raw_data/to_processed/bestsellers/" + amazon_bestseller_file, Body=json.dumps(amazon_bestseller))  
    client.put_object(Bucket='amazon-products-extracts-chiranjeevi', Key="raw_data/to_processed/deals/" + amazon_deals_file, Body=json.dumps(amazon_deals))  

